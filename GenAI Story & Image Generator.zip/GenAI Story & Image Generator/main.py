import os
import json
import requests

from io import BytesIO
from urllib.parse import quote

import PIL
from dotenv import load_dotenv
from google import genai

from prompts import STORY_PROMPT


def main():
    load_dotenv()

    api_key = os.getenv("GEMINI_API_KEY")

    if not api_key:
        raise ValueError("GEMINI_API_KEY not found in .env file")

    client = genai.Client(api_key=api_key)

    topic = input("\nEnter Animation Topic: ")

    response = client.models.generate_content(
        model="gemini-2.5-flash",
        contents=f"""
{STORY_PROMPT}

Animation Topic:
{topic}
"""
    )

    story_text = response.text

    # Remove markdown formatting if present
    story_text = story_text.replace("```json", "").replace("```", "").strip()

    try:
        story_data = json.loads(story_text)
    except json.JSONDecodeError:
        print("Invalid JSON returned from Gemini.")
        return

    # Always use the user's input as the title
    story_data["title"] = topic

    os.makedirs("output", exist_ok=True)

    with open("output/story.json", "w", encoding="utf-8") as file:
        json.dump(story_data, file, indent=4)

    print("\n✓ story.json saved successfully.")

    image_prompt = story_data["scene"]["image_prompt"]

    print("\nGenerating Storyboard Image...")

    url = f"https://image.pollinations.ai/prompt/{quote(image_prompt)}"

    response = requests.get(url)

    if response.status_code != 200:
        print("Image generation failed.")
        return

    image = PIL.Image.open(BytesIO(response.content))

    image.save("output/storyboard_v1.png")

    print("✓ storyboard_v1.png saved.")


if __name__ == "__main__":
    main()